# Search Configuration: Apify and LinkedIn

## Actor settings (all runs)
| Setting | Value |
|---------|-------|
| Actor | `curious_coder/linkedin-jobs-scraper` |
| Jobs per URL | 15 to 20 |
| Scrape company details | ON |
| Output format | JSON |
| Fields to request | `id,title,companyName,location,workRemoteAllowed,workplaceTypes,employmentType,salary,seniorityLevel,industries,postedAt,applicantsCount` |
| Max cost per run | Flag if above [MAX_RUN_COST] |

## Search tracks and URLs
Build each URL by running the search on LinkedIn, then copying the address bar. Useful parameters:
- `keywords=` your title phrases in quotes joined with OR (URL-encoded)
- `location=` e.g. United+States
- `f_WT=2` remote only
- `f_JT=F` full-time only
- `f_E=` seniority (4 is mid-senior, 5 is director)
- `sortBy=DD` newest first

### Track 1: [TRACK_1_NAME]
```
https://www.linkedin.com/jobs/search/?keywords=[KEYWORDS_1]&location=[LOCATION]&f_WT=2&f_JT=F&sortBy=DD
```

### Track 2: [TRACK_2_NAME]
```
https://www.linkedin.com/jobs/search/?keywords=[KEYWORDS_2]&location=[LOCATION]&f_WT=2&f_JT=F&sortBy=DD
```

### Track 3: [TRACK_3_NAME]
```
https://www.linkedin.com/jobs/search/?keywords=[KEYWORDS_3]&location=[LOCATION]&f_JT=F&sortBy=DD
```

If LinkedIn changes its URL format and results look wrong, run the search by hand, copy the resulting URL, and use that.

## Filtering rules

### Auto-skip (no review needed)
| Category | Examples |
|----------|----------|
| Consulting firms | [YOUR LIST] |
| Staffing firms | [YOUR LIST] |
| Recruiting or job-matching platforms | [YOUR LIST] |
| Wrong function | [YOUR LIST] |
| Contract or temp | employmentType is not Full-time |
| Stale postings | Posted more than [STALE_DAYS] days ago |
| Location mismatch | [YOUR RULE] |

### Flag for manual review (keep, note in Why Match column)
- Salary field empty: note "VERIFY COMP"
- Pay range straddles the floor: note "VERIFY COMP"
- Company under 50 employees, no funding info: note "RESEARCH COMPANY"
- Title and scope do not match: note "VERIFY SCOPE"
- Possible recruiting platform: note "VERIFY COMPANY" and ask the user

## Browser fallback (only if Apify MCP is unreachable)
1. Go to `console.apify.com`. The user must already be logged in.
2. Open the Apify Store, search "LinkedIn Jobs Scraper" (curious_coder).
3. Paste the LinkedIn URL(s), set jobs to 15 to 20, turn Scrape Company Details ON.
4. Click Save and Start. Wait for "Succeeded".
5. Get the run's dataset using your Apify API token. Never write the token into this file or into chat logs.
6. Request: `https://api.apify.com/v2/actor-runs/{RUN_ID}/dataset/items?format=json&clean=true&fields=[FIELDS]&token={TOKEN}`
7. Always use the `fields=` parameter. Without it, the response is too large to parse.
