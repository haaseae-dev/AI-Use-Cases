# [YOUR NAME]: Profile, Criteria and Deal-Breakers

## Who you are
[2 to 3 sentences: your role, years of experience, industries, and the kind of work you do best.]

**Certifications:** [LIST]
**Education:** [DEGREES]
**Tools:** [LIST]

## Career highlights (used when scoring resume fit)
- [Highlight 1: scale, outcome, and your role]
- [Highlight 2]
- [Highlight 3]
- [Highlight 4]

## Target role criteria

**Titles (priority order, or "open" if title does not matter):**
1. [TITLE_1]
2. [TITLE_2]
3. [TITLE_3]

**Compensation:** [MIN] to [MAX] base plus bonus. Flag anything likely below [MIN].

**Location:**
- Primary: [e.g. 100% remote, US]
- Acceptable: [e.g. hybrid within X miles of CITY]
- Hard no: [e.g. relocation required]

**Industries:** [Open, or list preferred and excluded industries.]

## Deal-breakers (auto-skip)
- **Contract or temp roles.** Employment type must be Full-time.
- **Consulting and staffing firms** where you would manage client work instead of internal programs: [LIST COMPANIES]
- **Recruiting or job-matching platforms** posting for unnamed clients: [LIST]
- **Roles needing a security clearance:** [YES/NO and list of contractors]
- **Wrong function:** [LIST]
- **Relocation required:** [RULE]

## Resume tailoring principles
- Mirror the posting's language where it is true to your experience.
- Lead bullets with outcomes, then the action.
- Show executive visibility when the role is senior.
- Use scale numbers ([YOUR KEY NUMBERS]) when the posting cares about scale.
- If you built tools or dashboards with AI, say you used AI to build them.
- Never invent metrics, promotions, companies, or certifications.
