---
name: job-search-template
description: Job search workflow with three phases: scrape and filter LinkedIn postings into an Excel tracker, get a quick shortlist in chat, and analyze and tailor a resume to a specific job description. Use when the user asks to run a job search, get top picks, update the tracker, check resume fit, or tailor a resume.
---

# Job Search Skill (Template)

Replace every [PLACEHOLDER] before first use. Placeholders live in this file and in the two reference files.
Load `references/profile.md` and `references/search-config.md` at the start of every session.

**PROCESS RULE: plan before doing.** Before a search, rescrape, or multi-step edit, state what you will do (which track, which filters, what will be produced). If anything is unclear, confirm first. Small, reversible edits can go ahead with a one-line plan.

**TARGETING (edit to match your goals):**
1. Compensation floor: [MIN_COMP, e.g. $150K] base plus bonus. Flag roles likely below it before pursuing.
2. Focus: [TARGET_FOCUS, e.g. program management, product operations, AI enablement].
3. Level: [LEVEL_RULE, e.g. "Manager and up, do not rank by title"].

---

## PHASE 1: Full Job Search (scrape, filter, Excel)

Use when the user asks to "run a job search", "update my tracker", or "scrape LinkedIn".

### Step 1: Check the scraper connection
Check whether the Apify MCP tools are connected. If yes, use them. If no, tell the user before using the browser fallback in `references/search-config.md`.

### Step 2: Ask which track to run
Never assume. Ask:
> "Which search track(s) should I run?
> 1. [TRACK_1_NAME]
> 2. [TRACK_2_NAME]
> 3. [TRACK_3_NAME]
> 4. All tracks
> Or paste your own LinkedIn search URL."

Wait for the answer. State the plan (tracks, filters) before the scrape.

### Step 3: Run the scraper
Use the URLs for the chosen tracks from `references/search-config.md`.
- Actor: `curious_coder/linkedin-jobs-scraper`
- Jobs per URL: 15 to 20
- Scrape company details: ON
- Output: JSON
- Flag the cost first if a run would exceed [MAX_RUN_COST, e.g. $0.25].

### Step 4: Filter results
**Auto-skip:**
- Employment type is not Full-time
- Company is on the avoid list (staffing, consulting, or job-matching platforms; see config)
- Location does not fit [LOCATION_RULE]
- Title is the wrong function
- Level is below [MIN_LEVEL]
- Posted more than [STALE_DAYS, e.g. 7] days ago. Note the reason as "Stale posting (X days old)".

**Flag for review (keep, but note):**
- Salary field empty
- Pay range straddles the floor
- Company under 50 employees with no funding info
- Title and scope do not match: flag "VERIFY SCOPE"
- Company looks like a recruiting platform but is not on the avoid list: flag "VERIFY COMPANY" and ask the user

Do not skip or down-score on title or level alone unless the targeting rules above say so.

### Step 5: Add to Excel
Add qualifying jobs to a new sheet in `[TRACKER_FILENAME].xlsx`.
- Sheet name: `Apify Scrape - [Month Day]`
- Match the formatting of the most recent prior scrape sheet (banner row, tier fills, score fills, sources row).
- Include PURSUE and SKIP rows for transparency.
- Columns: #, Tier, Company, Role Title, Role Category, Posted (Days Open), Location, Work Mode, Salary Range, Salary at or above floor?, What the Company Does, Role Fit Score, Recommendation, Interview Likelihood, Offer Likelihood, Remote/Hybrid OK?, Level, Travel Risk, Burnout Risk, Overall Score /10, Why Match / What to Verify, Apply Link
- Banner row: run date, actor, total scraped, total kept, tier counts.
- Sources row (last row): run ID, actor, URLs, counts.
- Score honestly. Do not inflate. Name deal-breaker risk plainly.

---

## PHASE 1B: Quick Picks (chat only, no Excel)

Use when the user asks for "top picks" or "a shortlist".

1. Confirm the track(s). State the plan.
2. Scrape as in Phase 1 Step 3.
3. Apply the full Phase 1 Step 4 filters. Check the description text for salary and work arrangement.
4. Do not create or update the Excel tracker.
5. Rank what passes by, in order:
   a. Pay confirmed at or above the floor
   b. Work arrangement confirmed in the posting text
   c. Applicant count (LinkedIn "200" means 200+, so deprioritize; under about 150 is better)
   d. Real fit to the user's background. Rank VERIFY SCOPE roles below clean matches.
6. Return the top 3 to 5 in chat. Every pick MUST include: title, company, confirmed pay, confirmed work arrangement, posted date, one or two lines on why, and the direct job link.
7. If fewer than 3 clear the bar, say so. Do not pad the list.
8. Offer to save the full results to the tracker.

---

## PHASE 2: Resume Analysis and Tailoring

### Accepting the job
The user can give a tracker row number, a LinkedIn URL, or pasted job description text. If a page is blocked, ask for the pasted text.

### Step 1: Load resume and job description
- Master resume: `[MASTER_RESUME_PATH]`. Read the live file and confirm it is current before using it.
- Load the job description.
- If the employer would be auto-skipped in Phase 1, flag the conflict before continuing.

### Step 2: Gap analysis (present before editing)
Use this format:

**ROLE:** [Title] at [Company]
**OVERALL FIT:** [score /10] and one honest sentence

**WHERE THE RESUME ALREADY LANDS**: 3 to 5 bullets. Quote the job description phrase and the resume phrase.

**GAPS AND REPOSITIONING**: For each gap say what the posting wants, what the resume says, and the fix. Label each as:
- Language gap (word swap)
- Framing gap (rewrite to lead with outcomes)
- Experience gap (the user truly lacks it: flag it, never invent it)

**KEYWORDS MISSING**: Exact terms from the posting that are not in the resume (affects ATS screening).

**RECOMMENDED CHANGES**: Numbered. Each names the section, the bullet, and the change.

**WHAT NOT TO TOUCH**: Sections already strong for this role.

**HONEST ASSESSMENT**: If the role is a stretch, say so plainly.

Then ask: "Should I make all of these changes, some, or none?"

### Step 3: Make the changes (after approval)
1. Use the docx skill.
2. Start from the live master resume.
3. Apply only approved changes.
4. Never invent experience, credentials, metrics, or employers.
5. Name the file `Resume_[Company]_[RoleShortName].docx` and save to `outputs/`.
6. Give the file with 2 to 3 sentences on what changed.

---

## Guardrails
- Never fabricate experience, metrics, credentials, or results.
- Never add companies, roles, or certifications the user does not have.
- Do not apply to jobs or submit applications for the user.
- Do not expose or log API tokens.
- Flag any scraper run likely to exceed the cost limit before starting.
- Every job mentioned in any format must include its direct link.
- Plan before doing: state what you will run or edit before multi-step work.

## Reference files
| File | When to load |
|------|--------------|
| `references/profile.md` | Always. Background, criteria, deal-breakers. |
| `references/search-config.md` | Phase 1 and 1B. Search URLs, actor settings, filter lists, browser fallback. |
